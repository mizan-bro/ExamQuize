import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { CheckCircle, XCircle, RotateCcw, Home, Trophy, BookOpen } from 'lucide-react'
import { quizData } from './data/questions_data.js'
import './App.css'

function App() {
  const [currentScreen, setCurrentScreen] = useState('home') // 'home', 'quiz', 'result'
  const [selectedCategory, setSelectedCategory] = useState(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState('')
  const [answers, setAnswers] = useState([])
  const [score, setScore] = useState(0)
  const [showFeedback, setShowFeedback] = useState(false)
  const [language, setLanguage] = useState('en') // 'en' or 'bn'

  const currentQuestions = selectedCategory ? selectedCategory.questions : []
  const currentQuestion = currentQuestions[currentQuestionIndex]
  const progress = currentQuestions.length > 0 ? ((currentQuestionIndex + 1) / currentQuestions.length) * 100 : 0

  const startQuiz = (category) => {
    setSelectedCategory(category)
    setCurrentQuestionIndex(0)
    setSelectedAnswer('')
    setAnswers([])
    setScore(0)
    setShowFeedback(false)
    setCurrentScreen('quiz')
  }

  const selectAnswer = (answer) => {
    if (showFeedback) return
    setSelectedAnswer(answer)
  }

  const submitAnswer = () => {
    if (!selectedAnswer) return

    const isCorrect = selectedAnswer === currentQuestion.correctAnswer
    const newAnswer = {
      questionId: currentQuestion.id,
      selectedAnswer,
      correctAnswer: currentQuestion.correctAnswer,
      isCorrect
    }

    setAnswers([...answers, newAnswer])
    if (isCorrect) {
      setScore(score + 1)
    }
    setShowFeedback(true)
  }

  const nextQuestion = () => {
    if (currentQuestionIndex < currentQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
      setSelectedAnswer('')
      setShowFeedback(false)
    } else {
      setCurrentScreen('result')
    }
  }

  const resetQuiz = () => {
    setCurrentScreen('home')
    setSelectedCategory(null)
    setCurrentQuestionIndex(0)
    setSelectedAnswer('')
    setAnswers([])
    setScore(0)
    setShowFeedback(false)
  }

  const getOptionStyle = (option) => {
    if (!showFeedback) {
      return selectedAnswer === option 
        ? 'bg-blue-100 border-blue-500 text-blue-700' 
        : 'bg-white border-gray-200 hover:bg-gray-50'
    }

    if (option === currentQuestion.correctAnswer) {
      return 'bg-green-100 border-green-500 text-green-700'
    }
    
    if (option === selectedAnswer && option !== currentQuestion.correctAnswer) {
      return 'bg-red-100 border-red-500 text-red-700'
    }
    
    return 'bg-gray-100 border-gray-200 text-gray-500'
  }

  const getScoreColor = () => {
    const percentage = (score / currentQuestions.length) * 100
    if (percentage >= 80) return 'text-green-600'
    if (percentage >= 60) return 'text-yellow-600'
    return 'text-red-600'
  }

  // Home Screen
  if (currentScreen === 'home') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-800 mb-2">
              {language === 'bn' ? 'নেটওয়ার্কিং কুইজ অ্যাপ' : 'Networking Quiz App'}
            </h1>
            <p className="text-gray-600">
              {language === 'bn' 
                ? 'আপনার নেটওয়ার্কিং জ্ঞান পরীক্ষা করুন' 
                : 'Test your networking knowledge'}
            </p>
            <div className="mt-4">
              <Button
                onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                variant="outline"
                className="mr-2"
              >
                {language === 'en' ? 'বাংলা' : 'English'}
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {quizData.categories.map((category) => (
              <Card key={category.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-blue-600" />
                    <span className="text-lg">
                      {language === 'bn' ? category.namebn : category.name}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">
                    {category.questions.length} {language === 'bn' ? 'টি প্রশ্ন' : 'questions'}
                  </p>
                  <Button 
                    onClick={() => startQuiz(category)}
                    className="w-full"
                  >
                    {language === 'bn' ? 'শুরু করুন' : 'Start Quiz'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    )
  }

  // Quiz Screen
  if (currentScreen === 'quiz') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-3xl mx-auto">
          <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
              <Button onClick={resetQuiz} variant="outline" size="sm">
                <Home className="w-4 h-4 mr-2" />
                {language === 'bn' ? 'হোম' : 'Home'}
              </Button>
              <Badge variant="secondary">
                {language === 'bn' ? 'স্কোর' : 'Score'}: {score}/{currentQuestions.length}
              </Badge>
            </div>
            
            <div className="mb-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>
                  {language === 'bn' ? 'প্রশ্ন' : 'Question'} {currentQuestionIndex + 1} {language === 'bn' ? 'এর' : 'of'} {currentQuestions.length}
                </span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </div>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-xl">
                {currentQuestion?.question}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {['a', 'b', 'c', 'd'].map((option) => (
                  <button
                    key={option}
                    onClick={() => selectAnswer(option)}
                    disabled={showFeedback}
                    className={`w-full p-4 text-left border-2 rounded-lg transition-all ${getOptionStyle(option)}`}
                  >
                    <span className="font-semibold mr-3">{option.toUpperCase()})</span>
                    {currentQuestion?.options[option]}
                  </button>
                ))}
              </div>

              {showFeedback && (
                <div className="mt-6 p-4 rounded-lg bg-gray-50">
                  <div className="flex items-center gap-2 mb-2">
                    {selectedAnswer === currentQuestion.correctAnswer ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-600" />
                    )}
                    <span className="font-semibold">
                      {selectedAnswer === currentQuestion.correctAnswer 
                        ? (language === 'bn' ? 'সঠিক!' : 'Correct!') 
                        : (language === 'bn' ? 'ভুল!' : 'Incorrect!')}
                    </span>
                  </div>
                  <p className="text-gray-600">
                    {language === 'bn' ? 'সঠিক উত্তর' : 'Correct answer'}: {currentQuestion.correctAnswer.toUpperCase()}) {currentQuestion.options[currentQuestion.correctAnswer]}
                  </p>
                </div>
              )}

              <div className="mt-6 flex gap-3">
                {!showFeedback ? (
                  <Button 
                    onClick={submitAnswer} 
                    disabled={!selectedAnswer}
                    className="flex-1"
                  >
                    {language === 'bn' ? 'উত্তর জমা দিন' : 'Submit Answer'}
                  </Button>
                ) : (
                  <Button onClick={nextQuestion} className="flex-1">
                    {currentQuestionIndex < currentQuestions.length - 1 
                      ? (language === 'bn' ? 'পরবর্তী প্রশ্ন' : 'Next Question')
                      : (language === 'bn' ? 'ফলাফল দেখুন' : 'View Results')}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Result Screen
  if (currentScreen === 'result') {
    const percentage = Math.round((score / currentQuestions.length) * 100)
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-3xl mx-auto">
          <Card className="text-center">
            <CardHeader>
              <div className="mx-auto mb-4">
                <Trophy className="w-16 h-16 text-yellow-500 mx-auto" />
              </div>
              <CardTitle className="text-3xl mb-2">
                {language === 'bn' ? 'কুইজ সম্পন্ন!' : 'Quiz Complete!'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <div className={`text-6xl font-bold mb-2 ${getScoreColor()}`}>
                  {score}/{currentQuestions.length}
                </div>
                <div className={`text-2xl ${getScoreColor()}`}>
                  {percentage}%
                </div>
                <p className="text-gray-600 mt-2">
                  {language === 'bn' ? 'বিষয়' : 'Category'}: {language === 'bn' ? selectedCategory.namebn : selectedCategory.name}
                </p>
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">
                  {language === 'bn' ? 'পারফরমেন্স' : 'Performance'}
                </h3>
                <div className="text-left space-y-2">
                  <div className="flex justify-between">
                    <span>{language === 'bn' ? 'সঠিক উত্তর' : 'Correct Answers'}:</span>
                    <span className="text-green-600 font-semibold">{score}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>{language === 'bn' ? 'ভুল উত্তর' : 'Wrong Answers'}:</span>
                    <span className="text-red-600 font-semibold">{currentQuestions.length - score}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>{language === 'bn' ? 'মোট প্রশ্ন' : 'Total Questions'}:</span>
                    <span className="font-semibold">{currentQuestions.length}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button onClick={resetQuiz} variant="outline" className="flex-1">
                  <Home className="w-4 h-4 mr-2" />
                  {language === 'bn' ? 'হোমে ফিরুন' : 'Back to Home'}
                </Button>
                <Button onClick={() => startQuiz(selectedCategory)} className="flex-1">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  {language === 'bn' ? 'আবার চেষ্টা করুন' : 'Try Again'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return null
}

export default App

