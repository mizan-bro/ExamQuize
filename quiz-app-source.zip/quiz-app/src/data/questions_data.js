// Quiz Questions Data
export const quizData = {
  categories: [
    {
      id: 1,
      name: "Peer-to-Peer & Client-Server",
      namebn: "পিয়ার-টু-পিয়ার এবং ক্লায়েন্ট-সার্ভার",
      questions: [
        {
          id: 1,
          question: "Which of the following is true about Peer-to-Peer networks?",
          options: {
            a: "Centralized control",
            b: "Expensive to maintain", 
            c: "Each node can act as a server",
            d: "Requires a dedicated server"
          },
          correctAnswer: "c"
        },
        {
          id: 2,
          question: "In which model does a central server provide services to clients?",
          options: {
            a: "Peer-to-Peer",
            b: "Distributed",
            c: "Hybrid", 
            d: "Client-Server"
          },
          correctAnswer: "d"
        },
        {
          id: 3,
          question: "Which of the following is NOT an advantage of the Client-Server model?",
          options: {
            a: "Centralized security",
            b: "Easier data management",
            c: "High scalability",
            d: "Low cost"
          },
          correctAnswer: "d"
        },
        {
          id: 4,
          question: "Which network model is commonly used for file-sharing systems like BitTorrent?",
          options: {
            a: "Client-Server",
            b: "Peer-to-Peer",
            c: "Hybrid",
            d: "Centralized"
          },
          correctAnswer: "b"
        },
        {
          id: 5,
          question: "Which of the following is more suitable for small office or home networks?",
          options: {
            a: "Client-Server",
            b: "Peer-to-Peer",
            c: "Metropolitan Network",
            d: "Intranet"
          },
          correctAnswer: "b"
        },
        {
          id: 6,
          question: "Which network model provides centralized data backup?",
          options: {
            a: "Client-Server",
            b: "Peer-to-Peer",
            c: "Mesh Network",
            d: "Ad-hoc Network"
          },
          correctAnswer: "a"
        },
        {
          id: 7,
          question: "In Client-Server networks, clients are mainly responsible for:",
          options: {
            a: "Managing resources",
            b: "Providing services",
            c: "Requesting services",
            d: "Routing data"
          },
          correctAnswer: "c"
        },
        {
          id: 8,
          question: "Which is a disadvantage of Peer-to-Peer networks?",
          options: {
            a: "High cost",
            b: "Single point of failure",
            c: "Poor scalability",
            d: "Centralized control"
          },
          correctAnswer: "c"
        },
        {
          id: 9,
          question: "In a Peer-to-Peer network, each device is called a:",
          options: {
            a: "Client",
            b: "Server",
            c: "Node",
            d: "Router"
          },
          correctAnswer: "c"
        },
        {
          id: 10,
          question: "What is the main feature of a client in a client-server model?",
          options: {
            a: "It provides services",
            b: "It manages the network",
            c: "It initiates requests",
            d: "It routes data"
          },
          correctAnswer: "c"
        }
      ]
    },
    {
      id: 2,
      name: "Network Devices",
      namebn: "নেটওয়ার্ক ডিভাইস",
      questions: [
        {
          id: 11,
          question: "Which device connects two different networks?",
          options: {
            a: "Switch",
            b: "Hub",
            c: "Router",
            d: "Repeater"
          },
          correctAnswer: "c"
        },
        {
          id: 12,
          question: "A switch operates at which layer of the OSI model?",
          options: {
            a: "Network",
            b: "Data Link",
            c: "Application",
            d: "Session"
          },
          correctAnswer: "b"
        },
        {
          id: 13,
          question: "What does a modem do?",
          options: {
            a: "Filters packets",
            b: "Modulates and demodulates signals",
            c: "Stores IP addresses",
            d: "Routes data"
          },
          correctAnswer: "b"
        },
        {
          id: 14,
          question: "Which device amplifies and regenerates signals?",
          options: {
            a: "Router",
            b: "Switch",
            c: "Hub",
            d: "Repeater"
          },
          correctAnswer: "d"
        },
        {
          id: 15,
          question: "Which device sends incoming data packets only to the intended recipient?",
          options: {
            a: "Hub",
            b: "Switch",
            c: "Router",
            d: "Repeater"
          },
          correctAnswer: "b"
        },
        {
          id: 16,
          question: "Which device acts as a central connection point in a star topology?",
          options: {
            a: "Switch",
            b: "Router",
            c: "Hub",
            d: "Gateway"
          },
          correctAnswer: "c"
        },
        {
          id: 17,
          question: "A device that filters traffic and ensures network security is:",
          options: {
            a: "Firewall",
            b: "Switch",
            c: "Hub",
            d: "Modem"
          },
          correctAnswer: "a"
        },
        {
          id: 18,
          question: "Which device assigns dynamic IP addresses to computers?",
          options: {
            a: "DNS Server",
            b: "FTP Server",
            c: "DHCP Server",
            d: "Proxy Server"
          },
          correctAnswer: "c"
        },
        {
          id: 19,
          question: "Which device is used to store frequently accessed web content?",
          options: {
            a: "Proxy Server",
            b: "DNS Server",
            c: "Firewall",
            d: "Router"
          },
          correctAnswer: "a"
        },
        {
          id: 20,
          question: "Which device translates domain names to IP addresses?",
          options: {
            a: "DHCP",
            b: "DNS",
            c: "Router",
            d: "FTP"
          },
          correctAnswer: "b"
        }
      ]
    },
    {
      id: 3,
      name: "Transmission Media",
      namebn: "ট্রান্সমিশন মিডিয়া",
      questions: [
        {
          id: 21,
          question: "Which of the following is a guided transmission medium?",
          options: {
            a: "Microwave",
            b: "Infrared",
            c: "Coaxial cable",
            d: "Radio"
          },
          correctAnswer: "c"
        },
        {
          id: 22,
          question: "Which cable is immune to electromagnetic interference?",
          options: {
            a: "UTP",
            b: "Coaxial",
            c: "Fiber optic",
            d: "Twisted pair"
          },
          correctAnswer: "c"
        },
        {
          id: 23,
          question: "Which medium is most commonly used in LANs?",
          options: {
            a: "Fiber optic",
            b: "Microwave",
            c: "Twisted pair cable",
            d: "Radio wave"
          },
          correctAnswer: "c"
        },
        {
          id: 24,
          question: "What is the main disadvantage of wireless media?",
          options: {
            a: "Cost",
            b: "Speed",
            c: "Interference",
            d: "Weight"
          },
          correctAnswer: "c"
        },
        {
          id: 25,
          question: "Which medium offers the highest bandwidth?",
          options: {
            a: "Coaxial",
            b: "Twisted Pair",
            c: "Wireless",
            d: "Fiber Optic"
          },
          correctAnswer: "d"
        },
        {
          id: 26,
          question: "What is the full form of UTP?",
          options: {
            a: "Ultra Transmission Protocol",
            b: "Uniform Twisted Pair",
            c: "Unshielded Twisted Pair",
            d: "Universal Transfer Protocol"
          },
          correctAnswer: "c"
        },
        {
          id: 27,
          question: "Which of the following is an unguided medium?",
          options: {
            a: "Fiber optic",
            b: "Coaxial",
            c: "Microwave",
            d: "Twisted pair"
          },
          correctAnswer: "c"
        },
        {
          id: 28,
          question: "Which transmission media is used for satellite communication?",
          options: {
            a: "Coaxial cable",
            b: "Fiber optic",
            c: "Microwave",
            d: "UTP"
          },
          correctAnswer: "c"
        },
        {
          id: 29,
          question: "Which medium is best for long-distance communication?",
          options: {
            a: "Twisted pair",
            b: "Coaxial",
            c: "Fiber optic",
            d: "Wireless LAN"
          },
          correctAnswer: "c"
        },
        {
          id: 30,
          question: "Which of the following is NOT a guided media?",
          options: {
            a: "Twisted pair",
            b: "Coaxial cable",
            c: "Microwave",
            d: "Fiber optic"
          },
          correctAnswer: "c"
        }
      ]
    },
    {
      id: 4,
      name: "Addressing",
      namebn: "অ্যাড্রেসিং",
      questions: [
        {
          id: 31,
          question: "What is the size of an IPv4 address?",
          options: {
            a: "64-bit",
            b: "128-bit",
            c: "32-bit",
            d: "16-bit"
          },
          correctAnswer: "c"
        },
        {
          id: 32,
          question: "Which of the following is a valid IP address?",
          options: {
            a: "256.100.50.25",
            b: "192.168.1.1",
            c: "500.10.10.10",
            d: "10.0.0.256"
          },
          correctAnswer: "b"
        },
        {
          id: 33,
          question: "What does MAC in MAC address stand for?",
          options: {
            a: "Memory Address Code",
            b: "Media Access Control",
            c: "Main Access Control",
            d: "Machine Access Code"
          },
          correctAnswer: "b"
        },
        {
          id: 34,
          question: "Which protocol maps IP addresses to MAC addresses?",
          options: {
            a: "DNS",
            b: "DHCP",
            c: "ARP",
            d: "ICMP"
          },
          correctAnswer: "c"
        },
        {
          id: 35,
          question: "Which address is assigned permanently to a device?",
          options: {
            a: "IP Address",
            b: "DNS Address",
            c: "Subnet Mask",
            d: "MAC Address"
          },
          correctAnswer: "d"
        },
        {
          id: 36,
          question: "Which of the following is a private IP address?",
          options: {
            a: "8.8.8.8",
            b: "192.168.0.1",
            c: "172.32.0.1",
            d: "11.0.0.1"
          },
          correctAnswer: "b"
        },
        {
          id: 37,
          question: "What does DNS stand for?",
          options: {
            a: "Domain Name Service",
            b: "Digital Network System",
            c: "Data Name Server",
            d: "Dynamic Name Setup"
          },
          correctAnswer: "a"
        },
        {
          id: 38,
          question: "What is subnetting used for?",
          options: {
            a: "Speeding up internet",
            b: "Dividing a network",
            c: "Creating MAC addresses",
            d: "Encrypting traffic"
          },
          correctAnswer: "b"
        },
        {
          id: 39,
          question: "What does DHCP stand for?",
          options: {
            a: "Dynamic Host Configuration Protocol",
            b: "Digital Host Control Program",
            c: "Domain Host Control Protocol",
            d: "Data Handling Communication Protocol"
          },
          correctAnswer: "a"
        },
        {
          id: 40,
          question: "What is the main purpose of IP addressing?",
          options: {
            a: "Store data",
            b: "Assign MAC addresses",
            c: "Identify devices on a network",
            d: "Encrypt messages"
          },
          correctAnswer: "c"
        }
      ]
    },
    {
      id: 5,
      name: "Mixed Concepts",
      namebn: "মিশ্র ধারণা",
      questions: [
        {
          id: 41,
          question: "Which protocol is used to assign dynamic IP addresses?",
          options: {
            a: "DNS",
            b: "ARP",
            c: "DHCP",
            d: "TCP"
          },
          correctAnswer: "c"
        },
        {
          id: 42,
          question: "Which layer of OSI is responsible for routing?",
          options: {
            a: "Session",
            b: "Data Link",
            c: "Network",
            d: "Transport"
          },
          correctAnswer: "c"
        },
        {
          id: 43,
          question: "Which device protects against unauthorized access?",
          options: {
            a: "Repeater",
            b: "Switch",
            c: "Firewall",
            d: "Hub"
          },
          correctAnswer: "c"
        },
        {
          id: 44,
          question: "Which device can reduce network traffic using intelligent forwarding?",
          options: {
            a: "Router",
            b: "Switch",
            c: "Hub",
            d: "Repeater"
          },
          correctAnswer: "b"
        },
        {
          id: 45,
          question: "A MAC address is used at which OSI layer?",
          options: {
            a: "Physical",
            b: "Network",
            c: "Data Link",
            d: "Transport"
          },
          correctAnswer: "c"
        },
        {
          id: 46,
          question: "How many classes are there in IPv4 addressing?",
          options: {
            a: "3",
            b: "5",
            c: "6",
            d: "2"
          },
          correctAnswer: "b"
        },
        {
          id: 47,
          question: "Which IP address class supports the most hosts?",
          options: {
            a: "Class A",
            b: "Class B",
            c: "Class C",
            d: "Class D"
          },
          correctAnswer: "a"
        },
        {
          id: 48,
          question: "Which port is used for HTTP?",
          options: {
            a: "21",
            b: "23",
            c: "80",
            d: "53"
          },
          correctAnswer: "c"
        },
        {
          id: 49,
          question: "What protocol is used to resolve domain names?",
          options: {
            a: "DHCP",
            b: "FTP",
            c: "DNS",
            d: "ARP"
          },
          correctAnswer: "c"
        },
        {
          id: 50,
          question: "Which device is used to increase the range of a wireless signal?",
          options: {
            a: "Router",
            b: "Repeater",
            c: "Switch",
            d: "Modem"
          },
          correctAnswer: "b"
        }
      ]
    }
  ]
};

export default quizData;

